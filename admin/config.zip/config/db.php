<?php
date_default_timezone_set('Asia/Jakarta');
    $his = date("d-m-Y H:i:s");
    $result = array('success' => "false", 'msg' => 'Nothing to do');
    $connect = mysqli_connect('localhost','richpool_user','@@Tegar@@123','richpool_user');
    if (!$connect) {
        die("Internal server error!");
    }
    
    
    function rewardCounter($id) {
        global $connect;
        $query = mysqli_query($connect, "SELECT a.*, b.package_id FROM users a INNER JOIN user_package b ON b.userid = a.id WHERE a.ref='$id'");
        $count = 0;
        $arr = array();
        if(mysqli_num_rows($query) > 0) {
            while($ro = mysqli_fetch_assoc($query)) {
                $n = mysqli_query($connect, "SELECT * FROM package WHERE package_id='".$ro['package_id']."'");
                $f = mysqli_fetch_array($n);
                $arr[]=$ro['id'];
                $count = $count+$f['price'];
            }
        }
        if(count($arr) > 0) {
            foreach($arr as $k => $v) {
                $zz = mysqli_query($connect, "SELECT a.*, b.package_id FROM users a INNER JOIN user_package b ON b.userid = a.id WHERE a.ref='$v'");
                $ff = mysqli_fetch_array($zz);
                $s = mysqli_query($connect, "SELECT * FROM package WHERE package_id='".$ff['package_id']."'");
                $d = mysqli_fetch_array($s);
                $count = $count+$d['price'];
            }
        }
        return $count;
    }
    
    function getUserByEmail($email) {
        global $connect;
        $query = mysqli_query($connect, "SELECT * FROM users WHERE email='$email'");
        $res = mysqli_fetch_array($query);
        return $res;
    }    
    function getUserByToken($token) {
        global $connect;
        $query = mysqli_query($connect, "SELECT * FROM token WHERE token='$token'");
        if(mysqli_num_rows($query) > 0) {
            $res = mysqli_fetch_array($query);
            return $res['user_id'];
        } else {
            return false;
        }
    }    
    function getUserEntireData($id) {
        global $connect;
        $query = mysqli_query($connect, "SELECT a.*,c.fund, f.fund as bonuses FROM users a
                                        LEFT JOIN bonus f ON f.user_id = a.id
                                        LEFT JOIN wallet c ON c.userid = a.id
                                        WHERE a.id='".$id."'");
        $res = mysqli_fetch_array($query);
        return $res;
    }    
    function getTotal($id) {
        global $connect;
        $query = mysqli_query($connect, "SELECT * FROM limitation WHERE uid='".$id."'");
        if(mysqli_num_rows($query) > 0) {
            $fetch = mysqli_fetch_array($query);
        } else {
            $fetch = 'notfound';
        }
        return $fetch;
    }
    function limitation($id) {
        global $connect;
        $query = mysqli_query($connect, "SELECT * FROM limitation WHERE uid='".$id."'");
        $fetch = mysqli_fetch_array($query);
        
        $limit = mysqli_fetch_array(mysqli_query($connect, "SELECT SUM(amount) as bonus FROM history WHERE user_id='".$id."' AND type IN ('sponsor','revshare','share')"));
        if($fetch['p_limit'] > $limit['bonus']) {
            $ret = 'true';
        
        } else if($fetch['p_limit'] < $limit['bonus']) {
            $check = mysqli_query($connect, "SELECT * FROM pending_profit WHERE uid='".$id."'");
            if(mysqli_num_rows($check) == 0) {
                mysqli_query($connect, "INSERT INTO pending_profit VALUES('','".$id."','0')");
            }
            $ret = 'false';
        }
        return $ret;
    }
    function convertIn($usd) {
        $rate = 16000;
        return $usd*$rate;
    }
    function convertOut($usd) {
        $rate = 14000;
        return $usd*$rate;
    }
    function getTotalDep($id) {
        global $connect;
        $query = mysqli_query($connect, "SELECT * FROM limitation WHERE uid='".$id."'");
        $ret = 0;
        if(mysqli_num_rows($query) > 0) {
            $fetch = mysqli_fetch_array($query);
            $ret = $ret+$fetch['total'];
        }
        return $ret;
    }
    function getReward($id) {
        global $connect;
        $query = mysqli_query($connect, "SELECT * FROM users WHERE id='".$id."'");
        $array = array();
        $fetch = mysqli_fetch_array($query);
        if($fetch['kiri'] !== null) {
            $array['kiri'][]= $fetch['kiri'];
        }
        if($fetch['kanan'] !== null) {
            $array['kanan'][]= $fetch['kanan'];
        }
        $volumes['kiri'] = 0;
        $volumes['kanan'] = 0;
        
        $cek = false;
        while(!$cek) {
            $arr['kanan'] = array();
            $arr['kiri']  = array();
            if(count($array['kanan']) > 0) {
                for($i=0; $i<=count($array['kanan'])-1; $i++) {
                    $get = mysqli_query($connect, "SELECT a.*, b.* FROM limitation a LEFT JOIN users b ON a.uid=b.id WHERE a.uid='".$array['kanan'][$i]."'");
                    $kanan = mysqli_fetch_array($get);
                    if($kanan['ref'] == $id) {
                        $getVol = getVolume($array['kanan'][$i]);
                        $volumes['kanan'] = $volumes['kanan'] + $getVol['kiri'] + $getVol['kanan'] + $kanan['total'];
                    } else {
                        if($kanan['kiri'] !== null) {
                            $arr['kanan'][]=$kanan['kiri'];
                        }
                        if($kanan['kanan'] !== null) {
                            $arr['kanan'][]=$kanan['kanan'];
                        }
                    }
                }
            }
            if(count($array['kiri']) > 0) {
                for($i=0; $i<=count($array['kiri'])-1; $i++) {
                    $get = mysqli_query($connect, "SELECT a.*, b.* FROM limitation a LEFT JOIN users b ON a.uid=b.id WHERE a.uid='".$array['kiri'][$i]."'");
                    $kiri = mysqli_fetch_array($get);
                    if($kiri['ref'] == $id) {
                        $getVol = getVolume($array['kiri'][$i]);
                        $volumes['kiri'] = $volumes['kiri'] + $getVol['kiri'] + $getVol['kanan'] + $kiri['total'];
                    } else {
                        if($kiri['kiri'] !== null) {
                            $arr['kiri'][]=$kiri['kiri'];
                        }
                        if($kiri['kanan'] !== null) {
                            $arr['kiri'][]=$kiri['kanan'];
                        }
                    }
                }
            }
            if(count($arr['kanan']) == 0 && count($arr['kiri']) == 0) {
                $cek = true;
            } else {
                $array=$arr;
            }
        }
        return $volumes;
    }
    function getVolume($id) {
        global $connect;
        $query = mysqli_query($connect, "SELECT * FROM geneology WHERE uid='".$id."'");
        $array=array();
        $array['kanan']= array();
        $array['kiri']= array();
        $fetch = mysqli_fetch_array($query);
        if($fetch['kiri'] !== null || !empty($fetch['kiri'])) {
            $array['kiri'][]= $fetch['kiri'];
        }
        if($fetch['kanan'] !== null || !empty($fetch['kanan'])) {
            $array['kanan'][]= $fetch['kanan'];
        }
        $volumes['kiri'] = 0;
        $volumes['kanan'] = 0;
        $cek = false;
        while(!$cek) {
            $arr = array('kanan' => [], 'kiri' => []);
            if(count($array['kanan']) > 0) {
                for($i=0; $i<count($array['kanan']); $i++) {
                    $get = mysqli_query($connect, "SELECT * FROM geneology WHERE uid='".$array['kanan'][$i]."'");
                    $total = getTotalDep($array['kanan'][$i]);
                    $kanan = mysqli_fetch_array($get);
                    $volumes['kanan'] = $volumes['kanan'] + $total;
                    if($kanan['kiri'] !== null || !empty($kanan['kiri'])) {
                        $arr['kanan'][]=$kanan['kiri'];
                    }
                    if($kanan['kanan'] !== null || !empty($kanan['kanan'])) {
                        $arr['kanan'][]=$kanan['kanan'];
                    }
                }
            }
            if(count($array['kiri']) > 0) {
                for($i=0; $i<count($array['kiri']); $i++) {
                    $get = mysqli_query($connect, "SELECT * FROM geneology WHERE uid='".$array['kiri'][$i]."'");
                    $total = getTotalDep($array['kiri'][$i]);
                    $kiri = mysqli_fetch_array($get);
                    $volumes['kiri'] = $volumes['kiri'] + $total;
                    
                    if($kiri['kiri'] !== null || !empty($kiri['kiri'])) {
                        $arr['kiri'][]=$kiri['kiri'];
                    }
                    if($kiri['kanan'] !== null | !empty($kiri['kanan'])) {
                        $arr['kiri'][]=$kiri['kanan'];
                    }
                }
            }
            if(count($arr['kanan']) == 0 && count($arr['kiri']) == 0) {
                $cek = true;
                break;
            } else {
                $array=$arr;
            }
        }
        return $volumes;
    }
    
    
    function getPackage($pack_id) {
        global $connect;
        $q = mysqli_query($connect, "SELECT * FROM package WHERE package_id = '$pack_id'");
        $f = mysqli_fetch_array($q);
        return $f;
    }
    function dataRefresher($token) {
        global $connect;
    	$user_id = getUserByToken($token);
    	if($user_id == false) {
    		$array = array('success' => 'false', 'type' => 'expired', 'msg' => 'Login Expired. Redirecting...');
    		echo json_encode($array);
    		exit;
    	} else {
        	$query = mysqli_query($connect, "SELECT * FROM users WHERE id = '".$user_id."'");
        	if(mysqli_num_rows($query) == 0) {
        		$array = array('success' => 'false', 'type' => 'expired', 'msg' => 'Login Expired. Redirecting...');
        		return false;
        	} else {
        	   
        		$user_data = getUserEntireData($user_id);
        		$new_user = array();
        		$news = mysqli_query($connect, "SELECT username, register_date FROM users ORDER BY id DESC LIMIT 20"); 
				while($roo = mysqli_fetch_assoc($news)) {
				    $new_user[]=$roo;
				}
				
        		// Counter //
        		$bonus_count = 0;
        		$bonus = mysqli_fetch_array(mysqli_query($connect, "SELECT SUM(amount) as leveling FROM history WHERE type='level' AND user_id='$user_id'"));
        		$bonus_count = $bonus_count+$bonus['leveling'];
        		
        		$refer_count = 0;
        		$refer = mysqli_fetch_array(mysqli_query($connect, "SELECT SUM(amount) as refer FROM history WHERE type='sponsor' AND user_id='$user_id'"));
        		$refer_count = $refer_count+$refer['refer'];
        		$total_count = $refer_count + $bonus_count;
        		
                $roadmap = rewardCounter($user_id);
                $array = array('user_data' => $user_data, 'total_count' => $total_count, 'bonus_count' => $bonus_count, 'refer_count' => $refer_count, 'roadmap' => $roadmap, 'new_user' => $new_user);
                return $array;
        	}
    	}
    }
    
				if(isset($_GET['p'])) {
				    $page = $_GET['p'];
				} else {
				    $page = 'none';
				}
				switch($page) {
				    case "wallet":
				        $now = "Wallet";
				        break;
				        
				    case "pedit":
				        $now = "EditProfile";
				        break;
				        
				    case "reg":
				        $now = "Registration";
				        break;
				        
				    case "tree":
				        $now = "TreeView";
				        break;
				        
				    case "ref": 
				        $now = "Referral";
				        break;
				        
				    case "trx":
				        $now = "Panel";
				        break;
				        
				    case "p2p":
				        $now = "Peer to Peer";
				        break;
				        
				    case "buypackage":
				        $now = "Package";
				        break;
				        
				    case "withdraw":
				        $now = "Withdraw";
				        break;
				        
				    case "history":
				        $now = "History";
				        break;
				    case "binary":
				        $now = "Network View";
				    default: 
				        $now = "Dashboard";
				}
?>