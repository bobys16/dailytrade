<?php

$title = "RICHPOOL";
$url = "https://richpool.io/";
$urlwww = "https://www.richpool.io/";
$mainpage = "dashboard/";

