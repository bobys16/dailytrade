<?php
namespace IEXBase\TronAPI\Exception;

use InvalidArgumentException;

class NotFoundException extends InvalidArgumentException
{
    //
}