<?php
namespace IEXBase\TronAPI\Exception;


class ErrorException extends \ErrorException
{

}