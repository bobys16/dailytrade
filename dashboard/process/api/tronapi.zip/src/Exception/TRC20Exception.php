<?php
namespace IEXBase\TronAPI\Exception;

class TRC20Exception extends TronException {
}
